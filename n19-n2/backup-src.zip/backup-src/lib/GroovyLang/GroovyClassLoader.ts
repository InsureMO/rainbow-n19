import {IClassLoader} from '../Java';

export interface GroovyClassLoader extends IClassLoader {
	// TODO IMPLEMENTS ME!
}
