export class JavaVoid {
}

export class JavaInteger {
}

export class JavaLong {
}

export class JavaBoolean {
}

export class JavaDouble {
}

export class JavaFloat {
}

export class JavaCharacter {
}

export class JavaShort {
}

export class JavaByte {
}

export class JavaBigInteger {
}

export class JavaBigDecimal {
}