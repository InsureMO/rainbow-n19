export interface HasCleanup {
	cleanup(): void;
}
